# Shard Client

Starter project for a client-side Fabric mod targeting **Minecraft Java 1.21.10**.

## Project details
- Minecraft: 1.21.10
- Fabric Loader: 0.17.2
- Fabric API: 0.138.4+1.21.10
- Java: 21
- GUI key: **M**
- Mod ID: `shardclient`

## Current starter build
- Opens the Shard Client screen with **M**.
- Includes toggle controls for planned modules.
- All toggles start **OFF**.
- Set Pos 1 / Set Pos 2 capture the player's current block coordinates.
- Position values are currently kept in memory and reset when the game restarts.

## Important status
This is the first source scaffold, not the finished client. The X-Ray, Chest ESP, Freecam, Fullbright, Auto Mine, Area Outline, and Smooth Camera buttons currently store toggle state only; their rendering/gameplay implementations are not included yet. Auto Mine does not break blocks in this starter build.

## Build
Use Java 21 and Gradle 8.12 or newer.

```bash
gradle build
```

The installable remapped mod JAR will be created in:

```text
build/libs/shard-client-0.1.0.jar
```

Install that JAR in the `mods` folder of a Fabric 1.21.10 profile, together with Fabric API.

## GitHub Actions
Pushing this project to GitHub will trigger the workflow in `.github/workflows/build.yml`, which builds the mod and uploads the JAR as an artifact.
