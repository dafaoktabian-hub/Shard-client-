package dev.shardclient;

import dev.shardclient.gui.ShardScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

public final class ShardClient implements ClientModInitializer {
    private static boolean menuKeyWasDown = false;

    public static boolean xrayEnabled = false;
    public static boolean chestEspEnabled = false;
    public static boolean freecamEnabled = false;
    public static boolean fullbrightEnabled = false;
    public static boolean autoMineEnabled = false;
    public static boolean areaOutlineEnabled = false;
    public static boolean smoothCameraEnabled = false;

    public static BlockPos pos1 = null;
    public static BlockPos pos2 = null;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.getWindow() == null) return;

            boolean down = GLFW.glfwGetKey(
                client.getWindow().getHandle(), GLFW.GLFW_KEY_M
            ) == GLFW.GLFW_PRESS;

            if (down && !menuKeyWasDown && client.currentScreen == null) {
                client.setScreen(new ShardScreen());
            }
            menuKeyWasDown = down;
        });
    }

    public static void capturePos1() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) pos1 = client.player.getBlockPos().toImmutable();
    }

    public static void capturePos2() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) pos2 = client.player.getBlockPos().toImmutable();
    }

    public static String posLabel(BlockPos pos) {
        return pos == null ? "Not set" : pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }
}
