package dev.shardclient.gui;

import dev.shardclient.ShardClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class ShardScreen extends Screen {
    private static final int BLUE = 0x55AAFF;

    public ShardScreen() {
        super(Text.literal("Shard Client"));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 104;
        int top = this.height / 2 - 100;
        int width = 208;
        int h = 20;
        int gap = 23;

        addDrawableChild(ButtonWidget.builder(toggleText("X-Ray", ShardClient.xrayEnabled),
                b -> { ShardClient.xrayEnabled = !ShardClient.xrayEnabled; b.setMessage(toggleText("X-Ray", ShardClient.xrayEnabled)); })
            .dimensions(left, top, width, h).build());

        addDrawableChild(ButtonWidget.builder(toggleText("Chest ESP", ShardClient.chestEspEnabled),
                b -> { ShardClient.chestEspEnabled = !ShardClient.chestEspEnabled; b.setMessage(toggleText("Chest ESP", ShardClient.chestEspEnabled)); })
            .dimensions(left, top + gap, width, h).build());

        addDrawableChild(ButtonWidget.builder(toggleText("Freecam", ShardClient.freecamEnabled),
                b -> { ShardClient.freecamEnabled = !ShardClient.freecamEnabled; b.setMessage(toggleText("Freecam", ShardClient.freecamEnabled)); })
            .dimensions(left, top + gap * 2, width, h).build());

        addDrawableChild(ButtonWidget.builder(toggleText("Fullbright", ShardClient.fullbrightEnabled),
                b -> { ShardClient.fullbrightEnabled = !ShardClient.fullbrightEnabled; b.setMessage(toggleText("Fullbright", ShardClient.fullbrightEnabled)); })
            .dimensions(left, top + gap * 3, width, h).build());

        addDrawableChild(ButtonWidget.builder(toggleText("Auto Mine", ShardClient.autoMineEnabled),
                b -> { ShardClient.autoMineEnabled = !ShardClient.autoMineEnabled; b.setMessage(toggleText("Auto Mine", ShardClient.autoMineEnabled)); })
            .dimensions(left, top + gap * 4, width, h).build());

        addDrawableChild(ButtonWidget.builder(toggleText("Area Outline", ShardClient.areaOutlineEnabled),
                b -> { ShardClient.areaOutlineEnabled = !ShardClient.areaOutlineEnabled; b.setMessage(toggleText("Area Outline", ShardClient.areaOutlineEnabled)); })
            .dimensions(left, top + gap * 5, width, h).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Set Pos 1: " + ShardClient.posLabel(ShardClient.pos1)),
                b -> { ShardClient.capturePos1(); b.setMessage("Set Pos 1: " + ShardClient.posLabel(ShardClient.pos1)); })
            .dimensions(left, top + gap * 6, width, h).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Set Pos 2: " + ShardClient.posLabel(ShardClient.pos2)),
                b -> { ShardClient.capturePos2(); b.setMessage("Set Pos 2: " + ShardClient.posLabel(ShardClient.pos2)); })
            .dimensions(left, top + gap * 7, width, h).build());

        addDrawableChild(ButtonWidget.builder(toggleText("Smooth Camera", ShardClient.smoothCameraEnabled),
                b -> { ShardClient.smoothCameraEnabled = !ShardClient.smoothCameraEnabled; b.setMessage(toggleText("Smooth Camera", ShardClient.smoothCameraEnabled)); })
            .dimensions(left, top + gap * 8, width, h).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"),
                b -> close())
            .dimensions(left, top + gap * 9, width, h).build());
    }

    private static Text toggleText(String name, boolean enabled) {
        return Text.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title,
            this.width / 2, this.height / 2 - 124, BLUE);
        context.drawCenteredTextWithShadow(this.textRenderer,
            Text.literal("Minecraft 1.21.10  |  Press M to open"),
            this.width / 2, this.height / 2 + 137, 0xAABBD0);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
